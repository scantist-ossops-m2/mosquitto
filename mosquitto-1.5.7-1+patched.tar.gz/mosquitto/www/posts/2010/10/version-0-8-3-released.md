<!--
.. title: Version 0.8.3 released
.. slug: version-0-8-3-released
.. date: 2010-10-04 21:01:59
.. tags: Releases
.. category:
.. link:
.. description:
.. type: text
-->

This is a bugfix release.

 * Fix compliance with the MQTT protocol for messages published at QoS 2. This
   means that messages that time out are dealt with correctly and duplicate
   messages are also dealt with correctly.

See the [download page] for the update.

[download page]: /download
