<!--
.. title: Mosquitto on QNX
.. slug: mosquitto-on-qnx
.. date: 2011-07-08 21:20:54
.. tags: Packaging
.. category:
.. link:
.. description:
.. type: text
-->

Andrea asked a [question on launchpad] about problems compiling Mosquitto on
QNX. I've now managed to get an evaluation version of QNX and fix the
compilation problems. These fixes will be in 0.12, but you can get them in the
current snapshot if it's urgent. I've also put compiled binaries in the
[downloads directory] but they are completely untested, so use at your own
risk.

Although I've provided these binaries I don't intend to keep doing so for each
version of Mosquitto. I will endeavour to fix any other problems that arise in
the future though.

[question on launchpad]: https://answers.launchpad.net/mosquitto/+question/164154
[downloads directory]: http://mosquitto.org/files/binary/qnx/
