<!--
.. title: Version 0.11.1 released
.. slug: version-0-11-1-released
.. date: 2011-06-20 19:40:18
.. tags: Releases
.. category:
.. link:
.. description:
.. type: text
-->

This is an important bugfix release. It fixes a buffer overrun that affects
0.11 only. Users of 0.11 should upgrade immediately.

 * Fix buffer overrun when checking for + and # in topics (bug #799688).
 * Pub client now quits if publish fails.

Thanks to Karl Palsson.
