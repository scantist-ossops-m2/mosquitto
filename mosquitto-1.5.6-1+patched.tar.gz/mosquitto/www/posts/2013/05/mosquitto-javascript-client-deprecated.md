<!--
.. title: Mosquitto Javascript client deprecated
.. slug: mosquitto-javascript-client-deprecated
.. date: 2013-05-07 17:53:33
.. tags: Misc,Releases
.. category:
.. link:
.. description:
.. type: text
-->

The [Paho] project recently made a new Javascript client available:
<http://git.eclipse.org/c/paho/org.eclipse.paho.mqtt.javascript.git>

The mosquitto Javascript client, mosquitto.js, is neither as functional nor as
well written as the Paho client, so is being deprecated. If you are using
mosquitto.js I strongly recommend that you look to the Paho client for the
future. I will be carrying out minor bug fixes but no other development will
take place.

There are no plans to remove the existing files.

[Paho]: http://www.eclipse.org/paho/
