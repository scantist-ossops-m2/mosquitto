<!--
.. title: One year old!
.. slug: one-year-old
.. date: 2010-10-25 09:16:44
.. tags:
.. category:
.. link:
.. description:
.. type: text
-->

On the 25th October 2009, at 21:40:51 (just five hours and forty minutes after
the first [oggcamp] ended :), I made the first commit to what would become the
mosquitto source code repository. Although there was no code committed until
the next day, and the first release wasn't until almost six weeks later, I
consider this to be when mosquitto was born.  It's been a good year. Thanks to
everybody who has helped out and been in touch!

I had hoped to release version 0.9 today, but it isn't to be. Nevertheless, I
hope you'll join me in hoping for an even more successful year ahead. I'm
aiming for a 1.0 release before this time next year with full MQTT 3.1 support,
full rsmb feature set (except where inappropriate), IPv6 support, SSL support,
language translation for the programs and man pages, full API documentation and
examples, and whatever I think of in the meantime.

Have a feature you're particularly interested in? Leave a comment! :)

[oggcamp]: http://oggcamp.org/
