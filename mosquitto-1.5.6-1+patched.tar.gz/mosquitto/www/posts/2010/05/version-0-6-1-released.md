<!--
.. title: Version 0.6.1 released
.. slug: version-0-6-1-released
.. date: 2010-05-06 12:44:06
.. tags: Releases
.. category:
.. link:
.. description:
.. type: text
-->

This fixes an important bug that didn't get caught for 0.6 that can prevent old
database versions being upgraded.

From 0.7 onwards, mosquitto will be using release candidates to ensure this
kind of problem doesn't occur in the future.
