<!--
.. title: Mind control MQTT
.. slug: mind-control-mqtt
.. date: 2010-04-14 13:06:03
.. tags: Applications
.. category:
.. link:
.. description:
.. type: text
-->

If you're in the UK, you may be interested in watching the Wednesday 21st April
episode of "Bang Goes the Theory". IBM employees [Nicholas O'Leary] and [Kevin
Brown] will be in one of the segments, on controlling remote control cars with
their minds - all with MQTT under the covers!

 * [BBC programme link]

[Nicholas O'Leary]: http://twitter.com/knolleary
[Kevin Brown]: http://twitter.com/kevinxbrown
[BBC programme link]: https://www.bbc.co.uk/programmes/b00s5fvq
