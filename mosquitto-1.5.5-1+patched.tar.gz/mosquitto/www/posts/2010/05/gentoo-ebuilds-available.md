<!--
.. title: Gentoo ebuilds available
.. slug: gentoo-ebuilds-available
.. date: 2010-05-18 16:48:11
.. tags: Packaging
.. category:
.. link:
.. description:
.. type: text
-->

Thanks to Neil Bothwick, there are now some Gentoo ebuilds available for
mosquitto and sqlite3-pcre. You can grab them from the links below - hopefully
they'll be integrated in the near future.

 * <http://bugs.gentoo.org/show_bug.cgi?id=320159>
 * <http://bugs.gentoo.org/show_bug.cgi?id=320153>
