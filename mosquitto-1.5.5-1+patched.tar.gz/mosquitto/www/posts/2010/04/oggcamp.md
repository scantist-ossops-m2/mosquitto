<!--
.. title: Oggcamp
.. slug: oggcamp
.. date: 2010-04-26 16:45:01
.. tags: Events
.. category:
.. link:
.. description:
.. type: text
-->

I'm going to be at [oggcamp] this coming weekend. If you're there, try and find
me and say hello! I'm planning a talk on mosquitto/mqtt with Andy
Stanford-Clark, so should be relatively easy to find.

[oggcamp]: http://oggcamp.org/
