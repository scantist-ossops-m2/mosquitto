<!--
.. title: MQTT Ontology
.. slug: mqtt-ontology
.. date: 2011-05-02 23:11:43
.. tags: Applications,Automation,Solutions
.. category:
.. link:
.. description:
.. type: text
-->

Mark Hindess has written a blog post titled [Home Automation Protocols: MQTT],
where he asks for suggestions on how to go forward making "a specification for
topic usage and semantics". I think this kind of work is really valuable to
make it easy to have different MQTT systems that can interoperate. If you've
got any suggestions you can make, please go and leave a comment
there.

[Home Automation Protocols: MQTT]: http://www.temporalanomaly.com/blog/2011/05/02/home-automation-protocols:-mqtt
